var novTrigger = document.getElementsByClassName('nov-trigger')[0],
body = document.getElementsByTagName('body')[0];

novTrigger.addEventListener('click', togglenovigation);

function togglenovigation(event) {
event.preventDefault();
body.classList.toggle('nov-open');
}
